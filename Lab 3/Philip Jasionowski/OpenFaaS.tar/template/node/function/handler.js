"use strict"

module.exports = async (context, callback) => {
    return {status: "done"}
}
